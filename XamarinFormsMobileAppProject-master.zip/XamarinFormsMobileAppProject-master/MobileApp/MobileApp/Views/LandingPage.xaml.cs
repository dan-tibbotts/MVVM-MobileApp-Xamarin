﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace MobileApp.Views
{
	[XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class LandingPage : ContentPage
	{
		public LandingPage ()
		{
			InitializeComponent ();
		}

        async private void MerchandiserButton_Clicked(object sender, EventArgs e)
        {
            await Navigation.PushAsync(new Views.Merchandiser.LoginPage());
        }

        async private void SupervisorButton_Clicked(object sender, EventArgs e)
        {
            await Navigation.PushAsync(new Views.Supervisor.SupervisorTabbedPage());
        }
    }
}