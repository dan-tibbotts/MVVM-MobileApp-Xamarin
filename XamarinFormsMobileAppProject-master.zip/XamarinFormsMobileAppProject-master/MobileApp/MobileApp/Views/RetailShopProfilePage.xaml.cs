﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace MobileApp.Views
{
	[XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class RetailShopProfilePage : ContentPage
	{
        Models.RetailShop SelectedRetailShop { get; set; }

		public RetailShopProfilePage (Models.RetailShop selectedRetailShop)
		{
			InitializeComponent ();
            SelectedRetailShop = selectedRetailShop;
		}

        protected override void OnAppearing()
        {
            base.OnAppearing();
            this.BindingContext = new ViewModels.RetailShopProfilePageViewModel(SelectedRetailShop);
        }
    }
}