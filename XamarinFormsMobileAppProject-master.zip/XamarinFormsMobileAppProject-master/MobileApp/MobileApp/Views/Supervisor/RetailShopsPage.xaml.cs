﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace MobileApp.Views.Supervisor
{
	[XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class RetailShopsPage : ContentPage
	{

        public Models.RetailShop SelectedRetailShop { get; set; }

		public RetailShopsPage ()
		{
			InitializeComponent ();
		}

        protected override void OnAppearing()
        {
            base.OnAppearing();
            this.BindingContext = new ViewModels.Supervisor.RetailShopsPageViewModel();
        }

        async private void AddButton_Clicked(object sender, EventArgs e)
        {
            await Navigation.PushModalAsync(new Views.RetailShopNewPage());
        }

        private void RetailShopListView_ItemSelected(object sender, SelectedItemChangedEventArgs e)
        {
            SelectedRetailShop = ((ViewModels.Supervisor.RetailShopsPageViewModel.SupervisorRetailShop)e.SelectedItem).RetailShop;
        }

        async private void RetailShopListView_ItemTapped(object sender, ItemTappedEventArgs e)
        {
            await Navigation.PushModalAsync(new Views.RetailShopProfilePage(SelectedRetailShop));
        }
    }
}