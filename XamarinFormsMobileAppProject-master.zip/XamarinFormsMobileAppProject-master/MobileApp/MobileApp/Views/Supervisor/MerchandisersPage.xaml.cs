﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace MobileApp.Views.Supervisor
{
	[XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class MerchandisersPage : ContentPage
	{
        public Models.Merchandiser SelectedMerchandiser { get; set; }

		public MerchandisersPage ()
		{
			InitializeComponent ();
		}

        protected override void OnAppearing()
        {
            base.OnAppearing();
            this.BindingContext = new ViewModels.Supervisor.MerchandisersPageViewModel();
        }

        private void MerchandiserListView_ItemSelected(object sender, SelectedItemChangedEventArgs e)
        {
            SelectedMerchandiser = (Models.Merchandiser)e.SelectedItem;
            
        }

        async private void MerchandiserListView_ItemTapped(object sender, ItemTappedEventArgs e)
        {
            await Navigation.PushModalAsync(new Views.MerchandiserProfilePage(SelectedMerchandiser));
        }

        async private void AddButton_Clicked(object sender, EventArgs e)
        {
            await Navigation.PushModalAsync(new Views.MerchandiserNewPage());
        }
    }
}