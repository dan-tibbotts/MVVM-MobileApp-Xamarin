﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace MobileApp.Views.Supervisor
{
	[XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class TicketsPage : ContentPage
	{
        public Models.Ticket SelectedTicket { get; set; }

        public TicketsPage ()
		{
			InitializeComponent ();
		}

        protected override void OnAppearing()
        {
            base.OnAppearing();
            this.BindingContext = new ViewModels.Supervisor.TicketsPageViewModel();
        }

        async private void AddButton_Clicked(object sender, EventArgs e)
        {
            await Navigation.PushModalAsync(new Views.TicketNewPage());
        }

        private void TicketListView_ItemSelected(object sender, SelectedItemChangedEventArgs e)
        {
            SelectedTicket = ((ViewModels.Supervisor.TicketsPageViewModel.SupervisorTicket)e.SelectedItem).Ticket;
        }

        async private void TicketListView_ItemTapped(object sender, ItemTappedEventArgs e)
        {
            await Navigation.PushModalAsync(new Views.TicketViewPage(SelectedTicket));
        }
    }
}