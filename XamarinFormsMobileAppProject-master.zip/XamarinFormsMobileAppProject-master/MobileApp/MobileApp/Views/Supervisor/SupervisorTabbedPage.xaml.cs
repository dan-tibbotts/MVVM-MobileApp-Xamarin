﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace MobileApp.Views.Supervisor
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class SupervisorTabbedPage : TabbedPage
    {
        public SupervisorTabbedPage ()
        {
            InitializeComponent();

            NavigationPage merchandisersPage = new NavigationPage(new Views.Supervisor.MerchandisersPage())
            {
                Title = "Merchandisers",
                Icon = "merchandisers.png"
            };

            NavigationPage retailShopPage = new NavigationPage(new Views.Supervisor.RetailShopsPage())
            {
                Title = "Retail Shops",
                Icon = "retailshops.png"
            };

            NavigationPage ticketsPage = new NavigationPage(new Views.Supervisor.TicketsPage())
            {
                Title = "Tickets",
                Icon = "tickets.png"
            };

            Children.Add(merchandisersPage);
            Children.Add(retailShopPage);
            Children.Add(ticketsPage);

        }


        protected override void OnAppearing()
        {
            base.OnAppearing();
        }

    }
}