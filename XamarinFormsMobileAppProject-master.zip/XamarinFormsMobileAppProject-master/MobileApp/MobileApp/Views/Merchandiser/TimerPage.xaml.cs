﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace MobileApp.Views.Merchandiser
{
	[XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class TimerPage : ContentPage
	{
        Models.Merchandiser SelectedMerchandiser;
		public TimerPage (Models.Merchandiser selectedMerchandiser)
		{
			InitializeComponent ();
            SelectedMerchandiser = selectedMerchandiser;
		}

        protected override void OnAppearing()
        {
            base.OnAppearing();
            this.BindingContext = new ViewModels.Merchandiser.TimerPageViewModel(SelectedMerchandiser);
        }
    }
}