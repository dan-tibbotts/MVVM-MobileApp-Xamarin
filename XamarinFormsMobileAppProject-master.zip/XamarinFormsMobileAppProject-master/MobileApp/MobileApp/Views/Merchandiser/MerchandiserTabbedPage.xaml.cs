﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace MobileApp.Views.Merchandiser
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class MerchandiserTabbedPage : TabbedPage
    {
        Models.Merchandiser SelectedMerchandiser;

        public MerchandiserTabbedPage (Models.Merchandiser selectedMerchandiser)
        {
            InitializeComponent();
            SelectedMerchandiser = selectedMerchandiser;

            NavigationPage dashboardPage = new NavigationPage(new Views.Merchandiser.DashboardPage(SelectedMerchandiser))
            {
                Title = "Dashboard",
                Icon = "dashboard.png"
            };

            NavigationPage timerPage = new NavigationPage(new Views.Merchandiser.TimerPage(SelectedMerchandiser))
            {
                Title = "Timer",
                Icon = "timer.png"
            };

            NavigationPage ticketsPage = new NavigationPage(new Views.Merchandiser.TicketsPage(SelectedMerchandiser))
            {
                Title = "Tickets",
                Icon = "tickets.png"
            };

            Children.Add(dashboardPage);
            Children.Add(timerPage);
            Children.Add(ticketsPage);

        }


        protected override void OnAppearing()
        {
            base.OnAppearing();
        }

    }


}