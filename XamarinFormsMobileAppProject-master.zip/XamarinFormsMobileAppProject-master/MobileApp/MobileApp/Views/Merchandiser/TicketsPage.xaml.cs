﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace MobileApp.Views.Merchandiser
{
	[XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class TicketsPage : ContentPage
	{
        Models.Merchandiser SelectedMerchandiser;
        Models.Ticket SelectedTicket;

		public TicketsPage (Models.Merchandiser selectedMerchandiser)
		{
			InitializeComponent ();
            SelectedMerchandiser = selectedMerchandiser;
		}

        protected override void OnAppearing()
        {
            base.OnAppearing();
            this.BindingContext = new ViewModels.Merchandiser.TicketsPageViewModel(SelectedMerchandiser);
        }

        private void TicketListView_ItemSelected(object sender, SelectedItemChangedEventArgs e)
        {
            SelectedTicket = ((ViewModels.Merchandiser.TicketsPageViewModel.MerchandiserTicket)e.SelectedItem).Ticket;
        }

        async private void TicketListView_ItemTapped(object sender, ItemTappedEventArgs e)
        {
            await Navigation.PushModalAsync(new Views.TicketViewPage(SelectedTicket));
        }

        async private void AddButton_Clicked(object sender, EventArgs e)
        {
            await Navigation.PushModalAsync(new Views.TicketNewPage());
        }
    }
}