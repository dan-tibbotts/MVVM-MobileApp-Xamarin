﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace MobileApp.Views.Merchandiser
{
	[XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class LoginPage : ContentPage
	{

        Models.Merchandiser SelectedMerchandiser;

        public LoginPage ()
		{
			InitializeComponent ();
		}

        protected override void OnAppearing()
        {
            base.OnAppearing();
            this.BindingContext = new ViewModels.Merchandiser.LoginPageViewModel();
        }

        private void MerchandiserListView_ItemSelected(object sender, SelectedItemChangedEventArgs e)
        {
            SelectedMerchandiser = (Models.Merchandiser)e.SelectedItem;
            
        }

        async private void CancelButton_Clicked(object sender, EventArgs e)
        {
            await Navigation.PopAsync();
        }

        async private void MerchandiserListView_ItemTapped(object sender, ItemTappedEventArgs e)
        {
            await Navigation.PushAsync(new Views.Merchandiser.MerchandiserTabbedPage(SelectedMerchandiser));
        }
    }
}