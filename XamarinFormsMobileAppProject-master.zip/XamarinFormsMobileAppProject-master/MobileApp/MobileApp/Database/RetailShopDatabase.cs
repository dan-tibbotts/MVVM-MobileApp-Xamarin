﻿using SQLite;
using System.Collections.Generic;
using System.Linq;
using Xamarin.Forms;


namespace MobileApp.Database
{
    public class RetailShopDatabase
    {

        private static SQLiteConnection database = DependencyService.Get<IDatabaseConnection>().DbConnection();
        private readonly static object collisionLock = new object();

        public RetailShopDatabase()
        {
            database.CreateTable<Models.RetailShop>();
        }

        public static IEnumerable<Models.RetailShop> GetRetailShops()
        {
            lock (collisionLock)
            {
                return database.Query<Models.RetailShop>("SELECT * FROM RetailShop").AsEnumerable();
            }
        }

        public static Models.RetailShop GetRetailShopById(int id)
        {
            lock (collisionLock)
            {
                return database.Table<Models.RetailShop>().FirstOrDefault(retailShop => retailShop.Id == id);
            }
        }


        public static void SaveRetailShop(Models.RetailShop retailShop)
        {
            lock (collisionLock)
            {
                if (retailShop.Id != 0)
                {
                    database.Update(retailShop);
                }
                else
                {
                    database.Insert(retailShop);
                }

            }
        }


        public static void DeleteRetailShop(Models.RetailShop retailShop)
        {
            var id = retailShop.Id;

            if (id != 0)
            {
                lock (collisionLock)
                {
                    database.Delete<Models.RetailShop>(id);
                }
            }
        }


        public static void DeleteAllRetailShops()
        {
            lock (collisionLock)
            {
                database.DropTable<Models.RetailShop>();
                database.CreateTable<Models.RetailShop>();
            }
        }

    }
}
