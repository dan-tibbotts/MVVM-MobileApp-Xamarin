﻿using SQLite;
using System.Collections.Generic;
using System.Linq;
using Xamarin.Forms;

namespace MobileApp.Database
{
    public class TimeRecordDatabase
    {
        private static SQLiteConnection database = DependencyService.Get<IDatabaseConnection>().DbConnection();
        private readonly static object collisionLock = new object();
        private static readonly System.DateTime NoSuppliedDate = new System.DateTime();

        public TimeRecordDatabase()
        {
            database.CreateTable<Models.TimeRecord>();
        }

        public static IEnumerable<Models.TimeRecord> GetTimeRecords()
        {
            lock (collisionLock)
            {
                return database.Query<Models.TimeRecord>("SELECT * FROM TimeRecord").AsEnumerable();
            }
        }

        public static Models.TimeRecord GetTimeRecordById(int id)
        {
            lock (collisionLock)
            {
                return database.Table<Models.TimeRecord>().FirstOrDefault(timeRecord => timeRecord.Id == id);
            }
        }

        public static IEnumerable<Models.TimeRecord> GetMerchandiserTimeRecords(Models.Merchandiser merchandiser)
        {
            lock (collisionLock)
            {
                return database.Query<Models.TimeRecord>($"SELECT * FROM TimeRecord WHERE MerchandiserId == {merchandiser.Id} ORDER BY StartTime DESC").AsEnumerable();
            }
        }

        public static Models.TimeRecord GetMerchandiserCurrentTimeRecord(Models.Merchandiser merchandiser)
        {
            lock (collisionLock)
            {
                return database.Table<Models.TimeRecord>().FirstOrDefault(timeRecord => timeRecord.MerchandiserId == merchandiser.Id && timeRecord.EndTime == NoSuppliedDate);
            }
        }


        public static IEnumerable<Models.TimeRecord> GetTimeRecordsByTicket(Models.Ticket ticket)
        {
            lock (collisionLock)
            {
                return database.Query<Models.TimeRecord>($"SELECT * FROM TimeRecord WHERE TicketId == {ticket.Id}").AsEnumerable();
            }
        }


        public static void SaveTimeRecord(Models.TimeRecord timeRecord)
        {
            lock (collisionLock)
            {
                if (timeRecord.Id != 0)
                {
                    database.Update(timeRecord);
                }
                else
                {
                    database.Insert(timeRecord);
                }
            }
        }


        public static void DeleteTimeRecord(Models.TimeRecord timeRecord)
        {
            var id = timeRecord.Id;

            if (id != 0)
            {
                lock (collisionLock)
                {
                    database.Delete<Models.TimeRecord>(id);
                }
            }
        }


        public static void DeleteAllTimeRecords()
        {
            lock (collisionLock)
            {
                database.DropTable<Models.TimeRecord>();
                database.CreateTable<Models.TimeRecord>();
            }
        }

    }
}
