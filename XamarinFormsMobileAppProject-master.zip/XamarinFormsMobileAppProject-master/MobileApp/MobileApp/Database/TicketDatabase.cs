﻿using SQLite;
using System.Collections.Generic;
using System.Linq;
using Xamarin.Forms;

namespace MobileApp.Database
{
    public class TicketDatabase
    {
        private static SQLiteConnection database = DependencyService.Get<IDatabaseConnection>().DbConnection();
        private readonly static object collisionLock = new object();


        public TicketDatabase()
        {
            database.CreateTable<Models.Ticket>();
        }

        public static IEnumerable<Models.Ticket> GetTickets()
        {
            lock (collisionLock)
            {
                return database.Query<Models.Ticket>("SELECT * FROM Ticket ORDER BY Status DESC, ScheduledDate ASC").AsEnumerable();
            }
        }

        public static Models.Ticket GetTicketById(int id)
        {
            lock (collisionLock)
            {
                return database.Table<Models.Ticket>().FirstOrDefault(ticket => ticket.Id == id);
            }
        }

        public static IEnumerable<Models.Ticket> GetMerchandiserTickets(Models.Merchandiser merchandiser)
        {
            lock (collisionLock)
            {
                return database.Query<Models.Ticket>($"SELECT * FROM Ticket WHERE MerchandiserId = {merchandiser.Id} ORDER BY Status DESC, ScheduledDate ASC").AsEnumerable();
            }
        }


        public static IEnumerable<Models.Ticket> GetRetailShopOpenTickets(Models.RetailShop retailShop)
        {
            lock (collisionLock)
            {
                return database.Query<Models.Ticket>($"SELECT * FROM Ticket WHERE RetailShopId = {retailShop.Id} AND Status = 'Open'").AsEnumerable();
            }
        }


        public static void SaveTicket(Models.Ticket ticket)
        {
            lock (collisionLock)
            {
                if (ticket.Id != 0)
                {
                    database.Update(ticket);
                }
                else
                {
                    database.Insert(ticket);
                }
            }
        }


        public static void DeleteTicket(Models.Ticket ticket)
        {
            var id = ticket.Id;

            if (id != 0)
            {
                lock (collisionLock)
                {
                    database.Delete<Models.Ticket>(id);
                }
            }
        }


        public static void DeleteAllTickets()
        {
            lock (collisionLock)
            {
                database.DropTable<Models.Ticket>();
                database.CreateTable<Models.Ticket>();
            }
        }
    }
}
