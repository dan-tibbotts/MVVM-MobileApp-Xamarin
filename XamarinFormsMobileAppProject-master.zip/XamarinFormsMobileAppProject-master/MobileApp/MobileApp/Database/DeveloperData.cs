﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobileApp.Database
{
    /// <summary>
    /// Creates dummy SQLite data for development and testing purposes
    /// </summary>
    public static class DeveloperData
    {

        // Merchandisers
        public static void CreateMerchandisers()
        {
            MerchandiserDatabase.DeleteAllMerchandisers();

            var merchandisersList = new List<Models.Merchandiser>()
            {
                new Models.Merchandiser { Name="Barney Rubble", Phone="123 456 789", Email="b.rubble@bedrock.com"},
                new Models.Merchandiser { Name="Frank Grimes", Phone="789 456 123", Email="grimey@friendsofhomer.com"},
                new Models.Merchandiser { Name="Perry Platypus", Phone="987 654 321", Email="agentp@danville.com"},
                new Models.Merchandiser { Name="Papa Smurf", Phone="852 741 852", Email="papa@smurf.com"},
            };

            foreach (var merchandiser in merchandisersList)
            {
                MerchandiserDatabase.SaveMerchandiser(merchandiser);
            }
        }


        // Tickets
        public static void CreateTickets()
        {
            TicketDatabase.DeleteAllTickets();

            var ticketsList = new List<Models.Ticket>()
            {
                new Models.Ticket { Title = "Winter Collection", Status="Open", MerchandiserId=2, RetailShopId=1, ScheduledDate=new DateTime(2021,04,19) },
                new Models.Ticket { Title = "Blanket Display", Status="Open", MerchandiserId=1, RetailShopId=2, ScheduledDate=new DateTime(2021, 04, 20) },
                new Models.Ticket { Title = "Smegg Kitchen Display", Status="Open", MerchandiserId=4, RetailShopId=4, ScheduledDate= new DateTime(2021, 04, 30) },
                new Models.Ticket { Title = "Pyjama Sale", Status="Closed", MerchandiserId=3, RetailShopId=6, ScheduledDate=DateTime.Now },
            };

            foreach (var ticket in ticketsList)
            {
                TicketDatabase.SaveTicket(ticket);
            }

        }



        // Retail Shops
        public static void CreateRetailShops()
        {
            RetailShopDatabase.DeleteAllRetailShops();

            var retailShopsList = new List<Models.RetailShop>()
            {
                new Models.RetailShop { Name="The Warehouse", Phone="03 337 4427", Email="info@thewarehouse.co.nz"},
                new Models.RetailShop { Name="Farmers", Phone="03 348 0889", Email="farmers@farmers.co.nz"},
                new Models.RetailShop { Name="Shopology", Phone="03 365 9505", Email="store@shopology.co.nz"},
                new Models.RetailShop { Name="Kathmandu", Phone="03 348 0152", Email="adventure@kathmandu.co.nz"},
                new Models.RetailShop { Name="Jay Car Electronics", Phone="03 379 1662", Email="digital@jaycar.co.nz"},
                new Models.RetailShop { Name="Bed Bath & Beyond", Phone="03 341 0949", Email="info@bbb.nz"},
            };

            foreach (var retailShop in retailShopsList)
            {
                RetailShopDatabase.SaveRetailShop(retailShop);
            }

        }



        // Time Records
        public static void CreateTimeRecords()
        {
            TimeRecordDatabase.DeleteAllTimeRecords();

            var timeRecordsList = new List<Models.TimeRecord>()
            {
                new Models.TimeRecord { MerchandiserId=2, TicketId=1, StartTime = new DateTime(2021,04,22,8,00,00), EndTime = new DateTime(2021,04,22,10,00,00)},
                new Models.TimeRecord { MerchandiserId=2, TicketId=1, StartTime = new DateTime(2021,04,22,10,30,00), EndTime = new DateTime(2021,04,22,12,30,00)},
                new Models.TimeRecord { MerchandiserId=1, TicketId=2, StartTime = new DateTime(2021,04,22,9,00,00), EndTime = new DateTime(2021,04,22,10,00,00)},
                new Models.TimeRecord { MerchandiserId=1, TicketId=2, StartTime = new DateTime(2021,04,22,12,00,00), EndTime = new DateTime(2021,04,22,16,00,00)},
                new Models.TimeRecord { MerchandiserId=4, TicketId=3, StartTime = new DateTime(2021,04,22,16,00,00), EndTime = new DateTime(2021,04,22,20,00,00)},
                new Models.TimeRecord { MerchandiserId=4, TicketId=3, StartTime = new DateTime(2021,04,22,23,00,00), EndTime = new DateTime(2021,04,23,00,30,00)},
                new Models.TimeRecord { MerchandiserId=3, TicketId=4, StartTime = new DateTime(2021,04,22,7,30,00), EndTime = new DateTime(2021,04,22,9,45,00)},
                new Models.TimeRecord { MerchandiserId=4, TicketId=4, StartTime = (DateTime.Now.AddHours(-1.25))},
            };

            foreach (var timeRecord in timeRecordsList)
            {
                TimeRecordDatabase.SaveTimeRecord(timeRecord);
            }
        }



    }
}
