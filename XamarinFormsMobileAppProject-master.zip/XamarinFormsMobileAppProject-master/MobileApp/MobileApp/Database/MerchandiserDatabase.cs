﻿using SQLite;
using System.Collections.Generic;
using System.Linq;
using Xamarin.Forms;


namespace MobileApp.Database
{
    public class MerchandiserDatabase
    {
        private static SQLiteConnection database = DependencyService.Get<IDatabaseConnection>().DbConnection(); 
        private readonly static object collisionLock = new object();

        public MerchandiserDatabase()
        {
            database.CreateTable<Models.Merchandiser>();
        }

        public static IEnumerable<Models.Merchandiser> GetMerchandisers()
        {
            lock (collisionLock)
            {
                return database.Query<Models.Merchandiser>("SELECT * FROM Merchandiser").AsEnumerable();
            }
        }

        public static Models.Merchandiser GetMerchandiserById(int id)
        {
            lock (collisionLock)
            {
                return database.Table<Models.Merchandiser>().FirstOrDefault(merchandiser => merchandiser.Id == id);
            }
        }


        public static void SaveMerchandiser(Models.Merchandiser merchandiser)
        {
            lock (collisionLock)
            {
                if (merchandiser.Id != 0)
                {
                    database.Update(merchandiser);
                }
                else
                {
                    database.Insert(merchandiser);
                }

            }
        }


        public static void DeleteMerchandiser(Models.Merchandiser merchandiser)
        {
            var id = merchandiser.Id;

            if (id != 0)
            {
                lock (collisionLock)
                {
                    database.Delete<Models.Merchandiser>(id);
                }
            }
        }


        public static void DeleteAllMerchandisers()
        {
            lock (collisionLock)
            {
                database.DropTable<Models.Merchandiser>();
                database.CreateTable<Models.Merchandiser>();
            }
        }

    }
}
