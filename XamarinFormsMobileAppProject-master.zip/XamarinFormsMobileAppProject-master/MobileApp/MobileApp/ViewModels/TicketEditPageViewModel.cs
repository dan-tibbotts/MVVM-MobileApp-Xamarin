﻿using System;
using System.Collections.Generic;
using System.Text;
using Xamarin.Forms;

namespace MobileApp.ViewModels
{
    public class TicketEditPageViewModel
    {
        public string PageTitle { get; } = "Edit Ticket";

        public Models.Ticket SelectedTicket { get; set; }
        private Models.Ticket OriginalData = new Models.Ticket();

        public List<string> Status { get; } = new List<string>() { "Open","Closed"};

        public List<Models.Merchandiser> Merchandisers { get; set; }
        public int SelectedMerchandiserIndex { get; set; } = -1;
        private Models.Merchandiser selectedMerchandiser;
        public Models.Merchandiser SelectedMerchandiser
        {
            get { return selectedMerchandiser; }
            set
            {
                selectedMerchandiser = value;
                SelectedTicket.MerchandiserId = selectedMerchandiser.Id;
            }
        }


        public List<Models.RetailShop> RetailShops { get; set; }
        public int SelectedRetailShopIndex { get; set; } = -1;
        private Models.RetailShop selectedRetailShop;
        public Models.RetailShop SelectedRetailShop
        {
            get { return selectedRetailShop; }
            set
            {
                selectedRetailShop = value;
                SelectedTicket.RetailShopId = selectedRetailShop.Id;
            }
        }


        public string TimeTaken
        {
            get
            {
                TimeSpan TimeSpanSum;

                var ticketTimeRecords = new List<Models.TimeRecord>(Database.TimeRecordDatabase.GetTimeRecordsByTicket(SelectedTicket));


                if (ticketTimeRecords.Count > 0)
                {
                    foreach (var timeRecord in ticketTimeRecords)
                    {
                        if (timeRecord.EndTime == new DateTime()) continue;

                        TimeSpan timeSpan = timeRecord.EndTime - timeRecord.StartTime;
                        TimeSpanSum += timeSpan;
                    }

                    return $"{TimeSpanSum.Hours}hrs {TimeSpanSum.Minutes}mins";
                }

                return "0hrs 0mins";
            }
        }


        public Command CancelCommand { get; set; }
        public Command SaveCommand { get; set; }


        public TicketEditPageViewModel(Models.Ticket selectedTicket)
        {
            SelectedTicket = selectedTicket;

            // Create a Copy of the Original Data
            OriginalData.Title = SelectedTicket.Title;
            OriginalData.RetailShopId = SelectedTicket.RetailShopId;
            OriginalData.MerchandiserId = SelectedTicket.MerchandiserId;
            OriginalData.ScheduledDate = SelectedTicket.ScheduledDate;
            OriginalData.Status = SelectedTicket.Status;
            OriginalData.Comment = SelectedTicket.Comment;


            Merchandisers = new List<Models.Merchandiser>(Database.MerchandiserDatabase.GetMerchandisers());
            RetailShops = new List<Models.RetailShop>(Database.RetailShopDatabase.GetRetailShops());

            // Set the Index for the Selected Merchandiser
            for (int i = 0; i < Merchandisers.Count; i++)
            {
                if (Merchandisers[i].Id == SelectedTicket.MerchandiserId)
                {
                    SelectedMerchandiserIndex = i;
                }
            }


            // Set the Index for the Selected Retail Shop
            for (int i = 0; i < RetailShops.Count; i++)
            {
                if (RetailShops[i].Id == SelectedTicket.RetailShopId)
                {
                    SelectedRetailShopIndex = i;
                }
            }


            CancelCommand = new Command(async () => {

                // Revert to Original Data
                SelectedTicket.Title = OriginalData.Title;
                SelectedTicket.RetailShopId = OriginalData.RetailShopId;
                SelectedTicket.MerchandiserId = OriginalData.MerchandiserId;
                SelectedTicket.ScheduledDate = OriginalData.ScheduledDate;
                SelectedTicket.Status = OriginalData.Status;
                SelectedTicket.Comment = OriginalData.Comment;

                await Application.Current.MainPage.Navigation.PopModalAsync();
            });


            SaveCommand = new Command( async() =>
            {
                Database.TicketDatabase.SaveTicket(SelectedTicket);
                await Application.Current.MainPage.Navigation.PopModalAsync();
            });
        }
    }
}
