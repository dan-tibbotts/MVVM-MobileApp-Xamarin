﻿using System;
using System.Collections.Generic;
using System.Text;
using Xamarin.Forms;

namespace MobileApp.ViewModels
{
    public class RetailShopEditPageViewModel
    {
        public string PageTitle { get; } = "Edit Retail Shop";
        public Models.RetailShop SelectedRetailShop { get; set; }
        private Models.RetailShop OriginalData = new Models.RetailShop();

        public Command CancelCommand { get; set; }
        public Command SaveCommand { get; set; }


        public RetailShopEditPageViewModel(Models.RetailShop selectedRetailShop)
        {
            SelectedRetailShop = selectedRetailShop;

            // Create a Copy Original Data 
            OriginalData.Name = selectedRetailShop.Name;
            OriginalData.Phone = selectedRetailShop.Phone;
            OriginalData.Email = selectedRetailShop.Email;


            CancelCommand = new Command(async () => {
                // Revert to Original Data
                selectedRetailShop.Name = OriginalData.Name;
                selectedRetailShop.Phone = OriginalData.Phone;
                selectedRetailShop.Email = OriginalData.Email;
                await Application.Current.MainPage.Navigation.PopModalAsync();
            });


            SaveCommand = new Command(async () => {
                Database.RetailShopDatabase.SaveRetailShop(selectedRetailShop);
                await Application.Current.MainPage.Navigation.PopModalAsync();
            });


        }
    }
}
