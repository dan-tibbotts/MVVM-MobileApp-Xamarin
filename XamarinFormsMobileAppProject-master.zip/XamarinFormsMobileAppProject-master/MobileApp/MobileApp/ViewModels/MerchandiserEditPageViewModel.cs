﻿using System;
using System.Collections.Generic;
using System.Text;
using Xamarin.Forms;

namespace MobileApp.ViewModels
{
    public class MerchandiserEditPageViewModel
    {
        public string PageTitle { get; } = "Edit Merchandiser Profile";

        public Models.Merchandiser SelectedMerchandiser { get; set; }
        public Models.Merchandiser OriginalData = new Models.Merchandiser();

        public Command SaveCommand { get; set; }
        public Command CancelCommand { get; set; }

        public MerchandiserEditPageViewModel(Models.Merchandiser selectedMerchandiser)
        {
            SelectedMerchandiser = selectedMerchandiser;

            // Create a Copy Original Data 
            OriginalData.Name = selectedMerchandiser.Name;
            OriginalData.Phone = selectedMerchandiser.Phone;
            OriginalData.Email = selectedMerchandiser.Email;


            CancelCommand = new Command( async()=> {

                // Revert to Original Data
                selectedMerchandiser.Name = OriginalData.Name;
                selectedMerchandiser.Phone = OriginalData.Phone;
                selectedMerchandiser.Email = OriginalData.Email;

                await Application.Current.MainPage.Navigation.PopModalAsync();
            });


            SaveCommand = new Command( async()=> {
                Database.MerchandiserDatabase.SaveMerchandiser(SelectedMerchandiser);
                await Application.Current.MainPage.Navigation.PopModalAsync();
            });
        }
    }
}
