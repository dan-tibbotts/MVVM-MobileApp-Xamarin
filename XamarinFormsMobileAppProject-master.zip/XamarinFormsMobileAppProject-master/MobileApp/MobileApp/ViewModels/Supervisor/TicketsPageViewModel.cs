﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;

namespace MobileApp.ViewModels.Supervisor
{
    public class TicketsPageViewModel
    {
        public string PageTitle { get; } = "Tickets";
        public ObservableCollection<Models.Ticket> Tickets { get; set; }
        public ObservableCollection<SupervisorTicket> SupervisorTickets { get; set; }

        public TicketsPageViewModel()
        {
            Tickets = new ObservableCollection<Models.Ticket>(Database.TicketDatabase.GetTickets());
            SupervisorTickets = new ObservableCollection<SupervisorTicket>();

            foreach (var ticket in Tickets)
            {
                SupervisorTickets.Add(new SupervisorTicket(ticket));
            }
        } 


        public class SupervisorTicket
        {
            public Models.Ticket Ticket { get; set; }

            public string Title { get { return $"#{Ticket.Id}: {Ticket.Title}"; } }

            public string Status { get { return Ticket.Status; } }

            public bool IsActive
            {
                get { return Ticket.Status != "Closed" && Ticket.ScheduledDate.Date <= DateTime.Today; }
            }

            public string RetailShopName
            {
                get
                {
                    Models.RetailShop retailShop = Database.RetailShopDatabase.GetRetailShopById(Ticket.RetailShopId);
                    return retailShop.Name;
                }
            }

            public string MerchandiserName
            {
                get
                {
                    Models.Merchandiser merchandiser = Database.MerchandiserDatabase.GetMerchandiserById(Ticket.MerchandiserId);
                    return merchandiser.Name;
                }
            }

            public SupervisorTicket(Models.Ticket ticket)
            {
                Ticket = new Models.Ticket();
                Ticket = ticket;
            }
        }

    }
}
