﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;

namespace MobileApp.ViewModels.Supervisor
{
    public class RetailShopsPageViewModel
    {
        public string PageTitle { get; } = "Retail Shops";

        public ObservableCollection<Models.RetailShop> RetailShops { get; set; }
        public ObservableCollection<SupervisorRetailShop> SupervisorRetailShops { get; set; }

        public RetailShopsPageViewModel()
        {
            RetailShops = new ObservableCollection<Models.RetailShop>(Database.RetailShopDatabase.GetRetailShops());
            SupervisorRetailShops = new ObservableCollection<SupervisorRetailShop>();

            foreach (var retailShop in RetailShops)
            {
                SupervisorRetailShops.Add(new SupervisorRetailShop(retailShop));
            }
        }


        public class SupervisorRetailShop
        {
            private List<Models.Ticket> retailShopOpenTickets;

            public Models.RetailShop RetailShop { get; set; }

            public int Id { get { return RetailShop.Id; } }
            public string Name { get { return RetailShop.Name; } }
            public string Phone { get { return RetailShop.Phone; } }
            public string Email { get { return RetailShop.Email; } }

            public int OpenTickets { get { return retailShopOpenTickets.Count; } }


            public SupervisorRetailShop(Models.RetailShop retailShop)
            {
                this.RetailShop = retailShop;
                retailShopOpenTickets = new List<Models.Ticket>(Database.TicketDatabase.GetRetailShopOpenTickets(retailShop));
            }
        }

    }
}
