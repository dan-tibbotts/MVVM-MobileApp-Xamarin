﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;

namespace MobileApp.ViewModels.Supervisor
{
    public class MerchandisersPageViewModel
    {
        public string PageTitle { get; } = "Merchandisers";
        public ObservableCollection<Models.Merchandiser> Merchandisers { get; set; }

        public MerchandisersPageViewModel()
        {
            Merchandisers = new ObservableCollection<Models.Merchandiser>(Database.MerchandiserDatabase.GetMerchandisers());
        }

    }
}
