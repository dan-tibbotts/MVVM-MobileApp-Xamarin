﻿using System;
using System.Collections.Generic;
using System.Text;
using Xamarin.Forms;

namespace MobileApp.ViewModels
{
    public class MerchandiserProfilePageViewModel
    {
        public string PageTitle { get; } = "Merchandiser Profile";

        public Models.Merchandiser SelectedMerchandiser { get; set; }

        public Command BackCommand { get; set; }
        public Command EditCommand { get; set; }
        public Command DeleteCommand { get; set; }
        

        public MerchandiserProfilePageViewModel(Models.Merchandiser selectedMerchandiser)
        {
            SelectedMerchandiser = selectedMerchandiser;

            BackCommand = new Command(async () => {
                await Application.Current.MainPage.Navigation.PopModalAsync();
            });


            EditCommand = new Command( async() => {
                await Application.Current.MainPage.Navigation.PushModalAsync(new Views.MerchandiserEditPage(selectedMerchandiser));
            });


            DeleteCommand = new Command( async()=> {
                bool deleteConfirmed = await Application.Current.MainPage.DisplayAlert("Confirm Delete", $"Are you sure you want to delete {selectedMerchandiser.Name} as a Merchandiser?", "Yes", "No");

                if (deleteConfirmed)
                {
                    Database.MerchandiserDatabase.DeleteMerchandiser(selectedMerchandiser);
                    await Application.Current.MainPage.Navigation.PopModalAsync();
                }
            });


        }
    }
}
