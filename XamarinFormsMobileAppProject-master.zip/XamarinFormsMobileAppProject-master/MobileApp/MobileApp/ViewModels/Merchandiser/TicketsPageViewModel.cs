﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;

namespace MobileApp.ViewModels.Merchandiser
{
    public class TicketsPageViewModel : NotifyPropertyChanged
    {
        public string PageTitle { get; } = "Tickets";

        public ObservableCollection<Models.Ticket> Tickets { get; set; }
        public ObservableCollection<MerchandiserTicket> MerchandiserTickets { get; set; }

        public Models.Merchandiser SelectedMerchandiser { get; set; }


        public TicketsPageViewModel(Models.Merchandiser selectedMerchandiser)
        {
            SelectedMerchandiser = selectedMerchandiser;

            Tickets = new ObservableCollection<Models.Ticket> (Database.TicketDatabase.GetMerchandiserTickets(SelectedMerchandiser));
            MerchandiserTickets = new ObservableCollection<MerchandiserTicket>();

            foreach (var ticket in Tickets)
            {
                MerchandiserTickets.Add(new MerchandiserTicket(ticket));
            }
        }


        public class MerchandiserTicket
        {
            public Models.Ticket Ticket { get; set; }

            public string DisplayHeading
            {
                get { return $"#{Ticket.Id}: {Ticket.Title}"; }
            }

            public bool IsActive
            {
               get { return Ticket.Status != "Closed" && Ticket.ScheduledDate.Date <= DateTime.Today; }
            }

            public string Status { get { return Ticket.Status; } }

            public string RetailShopName
            {
                get
                {
                    Models.RetailShop retailShop = Database.RetailShopDatabase.GetRetailShopById(Ticket.RetailShopId);
                    return retailShop.Name;
                }
            }

            public string TimeTaken
            {
                get
                {
                    TimeSpan TimeSpanSum;

                    var ticketTimeRecords = new List<Models.TimeRecord>(Database.TimeRecordDatabase.GetTimeRecordsByTicket(Ticket));


                    if (ticketTimeRecords.Count > 0)
                    {
                        foreach (var timeRecord in ticketTimeRecords)
                        {
                            if (timeRecord.EndTime == new DateTime()) continue;

                            TimeSpan timeSpan = timeRecord.EndTime - timeRecord.StartTime;
                            TimeSpanSum += timeSpan;
                        }

                        return $"{TimeSpanSum.Hours}hrs {TimeSpanSum.Minutes}mins";
                    }

                    return "0hrs 0mins";
                }
            }

            public MerchandiserTicket(Models.Ticket ticket)
            {
                Ticket = ticket;
            }

        }

    }
}
