﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Collections.ObjectModel;

namespace MobileApp.ViewModels.Merchandiser
{
    public class LoginPageViewModel : NotifyPropertyChanged
    {
        public string PageTitle { get; set; } = "Merchandiser Login";
        public ObservableCollection<Models.Merchandiser> Merchandisers { get; set; }

        public LoginPageViewModel()
        {
            Merchandisers = new ObservableCollection<Models.Merchandiser>(Database.MerchandiserDatabase.GetMerchandisers());
        }


    }
}
