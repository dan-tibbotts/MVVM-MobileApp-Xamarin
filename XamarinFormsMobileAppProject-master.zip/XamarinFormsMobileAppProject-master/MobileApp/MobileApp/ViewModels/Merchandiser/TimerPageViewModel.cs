﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;
using Xamarin.Forms;

namespace MobileApp.ViewModels.Merchandiser
{
    public class TimerPageViewModel : NotifyPropertyChanged
    {
        public string PageTitle { get; set; } = "Timer";

        public Models.Merchandiser SelectedMerchandiser { get; set; }

        public ObservableCollection<Models.TimeRecord> TimeRecords { get; set; }
        public ObservableCollection<MerchandiserTimeRecord> MerchandiserTimeRecords { get; set; }


        private MerchandiserTimeRecord currentMerchandiserTimeRecord;
        public MerchandiserTimeRecord CurrentMerchandiserTimeRecord
        {
            get { return currentMerchandiserTimeRecord; }
            set
            {
                currentMerchandiserTimeRecord = value;
                OnPropertyChanged();
            }
        }

        private string currentTicketTitle;
        public string CurrentTicketTitle
        {
            get { return currentTicketTitle; }
            set
            {
                currentTicketTitle = value;
                OnPropertyChanged();
            }
        }


        private string currentTimerStarted;
        public string CurrentTimerStarted
        {
            get { return currentTimerStarted; }
            set
            {
                currentTimerStarted = value;
                OnPropertyChanged();
            }
        }

        private string currentTimerTime;
        public string CurrentTimerTime
        {
            get { return currentTimerTime; }
            set
            {
                currentTimerTime = value;
                OnPropertyChanged();
            }
        }


        private bool timerSet = false;

        // Timer Button
        public Command TimerButtonCommand { get; set; }

        public string TimerButtonText
        {
            get
            {
                OnPropertyChanged();
                if (timerSet)
                {
                    return "Stop Timer";
                }
                else
                {
                    return "Start Timer";
                }
            }
        }

        private string timerButtonColor;
    
        public string TimerButtonColor
        {
            get
            {

                timerButtonColor = timerSet ? "#EB5757" : "#219653";
                return timerButtonColor;
            }
            set
            {
                timerButtonColor = value;
                OnPropertyChanged();
            }
        }



        public TimerPageViewModel(Models.Merchandiser selectedMerchandiser)
        {
            SelectedMerchandiser = selectedMerchandiser;

            TimeRecords = new ObservableCollection<Models.TimeRecord>(Database.TimeRecordDatabase.GetMerchandiserTimeRecords(SelectedMerchandiser));
            MerchandiserTimeRecords = new ObservableCollection<MerchandiserTimeRecord>();

            foreach (var timeRecord in TimeRecords)
            {

                MerchandiserTimeRecord merchandiserTimeRecord = new MerchandiserTimeRecord(timeRecord);
                MerchandiserTimeRecords.Add(merchandiserTimeRecord);

                if (timeRecord.EndTime == DateTime.MinValue)
                {
                    CurrentMerchandiserTimeRecord = merchandiserTimeRecord;
                    timerSet = true;
                }
                
            }


            Models.TimeRecord CurrentTimeRecord = Database.TimeRecordDatabase.GetMerchandiserCurrentTimeRecord(SelectedMerchandiser);

            if (CurrentTimeRecord != null)
            {
                TimeSpan CurrentTimeSpan = DateTime.Now - CurrentTimeRecord.StartTime;


                // Set TimerTicket Property
                Models.Ticket CurrentTimerTicket = Database.TicketDatabase.GetTicketById(CurrentTimeRecord.TicketId);
                CurrentTicketTitle = $"#{CurrentTimerTicket.Id}: {CurrentTimerTicket.Title}";

                // Populate Ticket Properties 
                CurrentTimerStarted = $"Timer Started: {CurrentTimeRecord.StartTime.ToString("dd/MM/yyyy hh:mm tt")}";
                CurrentTimerTime = $"{CurrentTimeSpan.Hours}hrs {CurrentTimeSpan.Minutes}mins";

            }
            else
            {
                CurrentTicketTitle = "No Current Timer Set";
                CurrentTimerStarted = "";
                CurrentTimerTime = "0hrs 0mins";

            }


            TimerButtonCommand = new Command( async()=> {


                if (timerSet)
                {
                
                    CurrentMerchandiserTimeRecord.TimeRecord.EndTime = DateTime.Now;
                    Database.TimeRecordDatabase.SaveTimeRecord(CurrentMerchandiserTimeRecord.TimeRecord);
                    // Set the timerSet to false
                    timerSet = false;

                    // Update ListView 
                    MerchandiserTimeRecords.Clear();
                    TimeRecords = new ObservableCollection<Models.TimeRecord>(Database.TimeRecordDatabase.GetMerchandiserTimeRecords(SelectedMerchandiser));

                    foreach (var timeRecord in TimeRecords)
                    {
                        MerchandiserTimeRecord merchandiserTimeRecord = new MerchandiserTimeRecord(timeRecord);
                        MerchandiserTimeRecords.Add(merchandiserTimeRecord);
                    }

                    // Update
                    CurrentTicketTitle = "No Current Timer Set";
                    CurrentTimerStarted = "";
                    CurrentTimerTime = "0hrs 0mins";

                    TimerButtonColor = "#219653";
                }
                else
                {
                    // Open new Time Record Screen
                    await Application.Current.MainPage.Navigation.PushModalAsync(new Views.TimeRecordNewPage());
                }
            });

        }

        public void GetTimeRecords()
        {
            ObservableCollection<Models.TimeRecord> timeRecords;
            timeRecords = new ObservableCollection<Models.TimeRecord>(Database.TimeRecordDatabase.GetMerchandiserTimeRecords(SelectedMerchandiser));
        }



        public class MerchandiserTimeRecord : NotifyPropertyChanged
        {

            private Models.TimeRecord timeRecord; 
            public Models.TimeRecord TimeRecord
            {
                get { return timeRecord; }
                set
                {
                    timeRecord = value;
                    OnPropertyChanged();
                }
            }

            public string DisplayHeading
            {
                get
                {
                    var ticket = new Models.Ticket();
                    ticket = Database.TicketDatabase.GetTicketById(TimeRecord.TicketId);
                    return $"#{ticket.Id}: {ticket.Title}";
                }
            }

            public string TotalHours
            {
                get
                {
                    if (TimeRecord.EndTime == DateTime.MinValue)
                    {
                        return "In Progress...";
                    }

                    TimeSpan timeSpan = TimeRecord.EndTime - TimeRecord.StartTime;
                    return $"{timeSpan.Hours}hrs {timeSpan.Minutes}mins";
                }
            }

            public string StartDate
            {
                get { return TimeRecord.StartTime.ToString("dd/MM/yyyy"); }
            }

            public string TimeRange
            {
                get
                {
                    if (TimeRecord.EndTime == DateTime.MinValue)
                    {
                        return $"{TimeRecord.StartTime.ToString("hh:mm tt")} - Current Time";
                    }

                    return $"{TimeRecord.StartTime.ToString("hh:mm tt")} - {TimeRecord.EndTime.ToString("hh:mm tt")}";
                }
            }

            public MerchandiserTimeRecord(Models.TimeRecord timeRecord)
            {
                TimeRecord = timeRecord;
            }
        }


    }
}
