﻿using System;
using System.Collections.Generic;
using System.Text;
using Xamarin.Forms;

namespace MobileApp.ViewModels.Merchandiser
{
    public class DashboardPageViewModel : NotifyPropertyChanged
    {
        public Models.Merchandiser SelectedMerchandiser { get; set; }
        public string PageTitle { get { return "Dashboard"; } }

        public string Name { get { return SelectedMerchandiser.Name; } }
        public string Phone { get { return SelectedMerchandiser.Phone; } }
        public string Email { get { return SelectedMerchandiser.Email; } }


        private readonly List<Models.Ticket> TicketsList;

        public int OpenTickets
        {
            get
            {
                int count = 0;
                foreach (var ticket in TicketsList)
                {
                    if (ticket.Status == "Open") count++;
                }
                return count;
            }
        }

        public int ClosedTickets
        {
            get
            {
                int count = 0;
                foreach (var ticket in TicketsList)
                {
                    if (ticket.Status == "Closed") count++;
                }
                return count;
            }
        }



        public string TimerTicketTitle { get; }
        public string TimerStarted { get; }
        public string TimerCurrentTime { get; }

        public Command NewTicketCommand { get; set; }

        public DashboardPageViewModel(Models.Merchandiser selectedMerchandiser)
        {
            SelectedMerchandiser = selectedMerchandiser;
            TicketsList = new List<Models.Ticket>(Database.TicketDatabase.GetMerchandiserTickets(SelectedMerchandiser));


            


            // Set TimeStarted Property

            Models.TimeRecord CurrentTimeRecord = Database.TimeRecordDatabase.GetMerchandiserCurrentTimeRecord(SelectedMerchandiser);

            if (CurrentTimeRecord != null)
            {
                TimeSpan CurrentTimeSpan = DateTime.Now - CurrentTimeRecord.StartTime;


                // Set TimerTicket Property
                Models.Ticket CurrentTimerTicket = Database.TicketDatabase.GetTicketById(CurrentTimeRecord.TicketId);
                TimerTicketTitle = $"#{CurrentTimerTicket.Id}: {CurrentTimerTicket.Title}";

                // Populate Ticket Properties 
                TimerStarted = $"Timer Started: {CurrentTimeRecord.StartTime.ToString("dd/MM/yyyy hh:mm tt")}";
                TimerCurrentTime = $"{CurrentTimeSpan.Hours}hrs {CurrentTimeSpan.Minutes}mins";

            }
            else
            {
                TimerTicketTitle = "No Current Timer Set";
                TimerStarted = "";
                TimerCurrentTime = "0hrs 0mins";
            }


            // Set Commands
            NewTicketCommand = new Command( async()=> {
                await Application.Current.MainPage.Navigation.PushModalAsync(new Views.TicketNewPage());
            });
        }


    }
}
