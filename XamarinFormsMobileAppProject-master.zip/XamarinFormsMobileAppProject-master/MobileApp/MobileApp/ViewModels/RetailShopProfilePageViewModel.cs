﻿using System;
using System.Collections.Generic;
using System.Text;
using Xamarin.Forms;

namespace MobileApp.ViewModels
{
    public class RetailShopProfilePageViewModel
    {
        public string PageTitle { get; } = "Retail Shop Profile";

        public Models.RetailShop SelectedRetailShop { get; set; }

        public Command BackCommand { get; set; }
        public Command EditCommand { get; set; }
        public Command DeleteCommand { get; set; }


        public RetailShopProfilePageViewModel(Models.RetailShop selectedRetailShop)
        {
            SelectedRetailShop = selectedRetailShop;


            BackCommand = new Command(async () => {
                await Application.Current.MainPage.Navigation.PopModalAsync();
            });


            EditCommand = new Command(async () =>
            {
                await Application.Current.MainPage.Navigation.PushModalAsync(new Views.RetailShopEditPage(selectedRetailShop));
            });


            DeleteCommand = new Command(async () => {
                bool deleteConfirmed = await Application.Current.MainPage.DisplayAlert("Confirm Delete", $"Are you sure you want to delete {selectedRetailShop.Name} as a Retail Shop?", "Yes", "No");

                if (deleteConfirmed)
                {
                    Database.RetailShopDatabase.DeleteRetailShop(selectedRetailShop);
                    await Application.Current.MainPage.Navigation.PopModalAsync();
                }
            });


        }



    }
}
