﻿using System;
using System.Collections.Generic;
using System.Text;
using Xamarin.Forms;

namespace MobileApp.ViewModels
{
    public class RetailShopNewPageViewModel
    {
        public string PageTitle { get; } = "New Retail Shop Profile";

        public Command CancelCommand { get; set; }
        public Command SaveCommand { get; set; }

        public string Name { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }

        public RetailShopNewPageViewModel()
        {

            CancelCommand = new Command(async () => {
                await Application.Current.MainPage.Navigation.PopModalAsync();
            });

            SaveCommand = new Command(async () => {
                var retailShop = new Models.RetailShop()
                {
                    Name = this.Name,
                    Email = this.Email,
                    Phone = this.Phone
                };

                Database.RetailShopDatabase.SaveRetailShop(retailShop);
                await Application.Current.MainPage.Navigation.PopModalAsync();
            });
        }
    }
}
