﻿using System;
using System.Collections.Generic;
using System.Text;
using Xamarin.Forms;

namespace MobileApp.ViewModels
{
    public class TicketNewPageViewModel
    {
        public string PageTitle { get; } = "New Ticket";

        public Models.Ticket Ticket { get; set; }
        

        public List<Models.Merchandiser> Merchandisers { get; set; }
        private Models.Merchandiser selectedMerchandiser;
        public Models.Merchandiser SelectedMerchandiser
        {
            get { return selectedMerchandiser; }
            set
            {
                selectedMerchandiser = value;
                Ticket.MerchandiserId = selectedMerchandiser.Id;
            }
        }

        public List<Models.RetailShop> RetailShops { get; set; }
        private Models.RetailShop selectedRetailShop;
        public Models.RetailShop SelectedRetailShop
        {
            get { return selectedRetailShop; }
            set
            {
                selectedRetailShop = value;
                Ticket.RetailShopId = selectedRetailShop.Id;
            }
        }

        public Command CancelCommand { get; set; }
        public Command SaveCommand { get; set; }


        public TicketNewPageViewModel()
        {
            Merchandisers = new List<Models.Merchandiser>(Database.MerchandiserDatabase.GetMerchandisers());
            RetailShops = new List<Models.RetailShop>(Database.RetailShopDatabase.GetRetailShops());

            Ticket = new Models.Ticket()
            {
                ScheduledDate = DateTime.Now,
                Status = "Open"
            };

            CancelCommand = new Command(async () => {
                await Application.Current.MainPage.Navigation.PopModalAsync();
            });

            SaveCommand = new Command(async () =>
            {
                Database.TicketDatabase.SaveTicket(Ticket);
                await Application.Current.MainPage.Navigation.PopModalAsync();
            });
        }
    }
}
