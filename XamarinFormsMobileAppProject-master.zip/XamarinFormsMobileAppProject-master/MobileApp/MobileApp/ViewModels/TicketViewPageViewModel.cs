﻿using System;
using System.Collections.Generic;
using System.Text;
using Xamarin.Forms;

namespace MobileApp.ViewModels
{
    public class TicketViewPageViewModel
    {
        public string PageTitle { get; } = "Ticket View";

        public Models.Ticket SelectedTicket { get; set; }

        public Models.Merchandiser Merchandiser
        {
            get
            {
                Models.Merchandiser merchandiser = Database.MerchandiserDatabase.GetMerchandiserById(SelectedTicket.MerchandiserId);
                return merchandiser;
            }
        }


        public Models.RetailShop RetailShop
        {
            get
            {
                Models.RetailShop retailShop = Database.RetailShopDatabase.GetRetailShopById(SelectedTicket.RetailShopId);
                return retailShop;
            }
        }


        public string TimeTaken
        {
            get
            {
                TimeSpan TimeSpanSum;
                
                var ticketTimeRecords = new List<Models.TimeRecord>(Database.TimeRecordDatabase.GetTimeRecordsByTicket(SelectedTicket));


                if (ticketTimeRecords.Count > 0)
                {
                    foreach (var timeRecord in ticketTimeRecords)
                    {
                        if (timeRecord.EndTime == new DateTime()) continue;

                        TimeSpan timeSpan = timeRecord.EndTime - timeRecord.StartTime;
                        TimeSpanSum += timeSpan;
                    }

                    return $"{TimeSpanSum.Hours}hrs {TimeSpanSum.Minutes}mins";
                }

                return "0hrs 0mins";
            }
        }


        public Command BackCommand { get; set; }
        public Command EditCommand { get; set; }
        public Command DeleteCommand { get; set; }

        public TicketViewPageViewModel(Models.Ticket selectedTicket)
        {
            SelectedTicket = selectedTicket;


            BackCommand = new Command(async () => {
                await Application.Current.MainPage.Navigation.PopModalAsync();
            });


            EditCommand = new Command(async () =>
            {
                await Application.Current.MainPage.Navigation.PushModalAsync(new Views.TicketEditPage(selectedTicket));
            });


            DeleteCommand = new Command(async () => {
                bool deleteConfirmed = await Application.Current.MainPage.DisplayAlert("Confirm Delete", $"Are you sure you want to delete the {SelectedTicket.Title} ticket for {RetailShop.Name}?", "Yes", "No");

                if (deleteConfirmed)
                {
                    Database.TicketDatabase.DeleteTicket(SelectedTicket);
                    await Application.Current.MainPage.Navigation.PopModalAsync();
                }
            });

        }

    }
}
