﻿using System;
using System.Collections.Generic;
using System.Text;
using Xamarin.Forms;

namespace MobileApp.ViewModels
{
    public class MerchandiserNewPageViewModel
    {
        public string PageTitle { get; } = "New Merchandiser Profile";

        public Command CancelCommand { get; set; }
        public Command SaveCommand { get; set; }

        public string Name { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }

        public MerchandiserNewPageViewModel()
        {

            CancelCommand = new Command( async()=> {
                await Application.Current.MainPage.Navigation.PopModalAsync();
            });


            SaveCommand = new Command( async()=> {
                var merchandiser = new Models.Merchandiser()
                {
                    Name = this.Name,
                    Email = this.Email, 
                    Phone = this.Phone
                };

                Database.MerchandiserDatabase.SaveMerchandiser(merchandiser);
                await Application.Current.MainPage.Navigation.PopModalAsync();
            });
        }
    }
}
