﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;
using Xamarin.Forms;

namespace MobileApp.ViewModels
{
    public class TimerRecordNewPageViewModel : NotifyPropertyChanged
    {
        public string PageTitle { get; } = "Start New Timer";

        public DateTime StartDate { get; set; } = DateTime.Now;
        public TimeSpan StartTime { get; set; } = DateTime.Now.TimeOfDay;

        public Models.Ticket SelectedTicket { get; set; }
        public Models.Merchandiser SelectedMerchandiser { get; set; }

        public ObservableCollection<Models.Ticket> Tickets { get; set; }
        public ObservableCollection<Models.Merchandiser> Merchandisers { get; set; }

        public Command CancelCommand { get; set; }
        public Command SaveCommand { get; set; }

        public TimerRecordNewPageViewModel()
        {

            SelectedTicket = new Models.Ticket();
            SelectedMerchandiser = new Models.Merchandiser();

            Tickets = new ObservableCollection<Models.Ticket>(Database.TicketDatabase.GetTickets());
            Merchandisers = new ObservableCollection<Models.Merchandiser>(Database.MerchandiserDatabase.GetMerchandisers());

            CancelCommand = new Command(async()=> {
                await Application.Current.MainPage.Navigation.PopModalAsync();
            });


            SaveCommand = new Command( async()=> {

                Models.TimeRecord timeRecord = new Models.TimeRecord()
                {
                    MerchandiserId = SelectedMerchandiser.Id,
                    TicketId = SelectedTicket.Id,
                    StartTime = (StartDate + StartTime),
                };

                Database.TimeRecordDatabase.SaveTimeRecord(timeRecord);
                await Application.Current.MainPage.Navigation.PopModalAsync();
            });

        }

    }
}
