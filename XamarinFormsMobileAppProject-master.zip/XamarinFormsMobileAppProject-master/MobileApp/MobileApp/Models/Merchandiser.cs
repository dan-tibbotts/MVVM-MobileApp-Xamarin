﻿using SQLite;
using System.ComponentModel;

namespace MobileApp.Models
{
    [Table("merchandiser")]
    public class Merchandiser : NotifyPropertyChanged
    {
        private int id;
        private string name;
        private string phone;
        private string email;
        private string image = "user.png";

        [PrimaryKey, AutoIncrement, Column("Id")]
        public int Id
        {
            get { return this.id; }
            set
            {
                this.id = value;
                OnPropertyChanged();
            }
        }

        [NotNull]
        public string Name
        {
            get { return this.name; }
            set
            {
                this.name = value;
                OnPropertyChanged();
            }
        }

        [NotNull]
        public string Phone
        {
            get { return this.phone; }
            set
            {
                this.phone = value;
                OnPropertyChanged();
            }
        }

        [NotNull]
        public string Email
        {
            get { return this.email; }
            set
            {
                this.email = value;
                OnPropertyChanged();
            }
        }

        public string Image
        {
            get { return this.image; }
            set
            {
                this.image = value;
                OnPropertyChanged();
            }
        }

    }
}

