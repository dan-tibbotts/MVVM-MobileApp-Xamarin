﻿using System;
using SQLite;

namespace MobileApp.Models
{
    [Table("timerecord")]
    public class TimeRecord : NotifyPropertyChanged
    {

        private int id;
        private int merchandiserId;
        private int ticketId;
        private DateTime startTime;
        private DateTime endTime;

        [PrimaryKey, AutoIncrement]
        public int Id
        {
            get { return this.id; }
            set
            {
                this.id = value;
                OnPropertyChanged();
            }
        }

        [NotNull]
        public int MerchandiserId
        {
            get { return this.merchandiserId; }
            set
            {
                this.merchandiserId = value;
                OnPropertyChanged();
            }
        }

        [NotNull]
        public int TicketId
        {
            get { return this.ticketId; }
            set
            {
                this.ticketId = value;
                OnPropertyChanged();
            }
        }

        [NotNull]
        public DateTime StartTime
        {
            get { return this.startTime; }
            set
            {
                this.startTime = value;
                OnPropertyChanged();
            }
        }

        public DateTime EndTime
        {
            get { return this.endTime; }
            set
            {
                this.endTime = value;
                OnPropertyChanged();
            }
        }

    }
}
