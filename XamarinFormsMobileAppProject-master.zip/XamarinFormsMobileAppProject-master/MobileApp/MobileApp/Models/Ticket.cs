﻿using System;
using SQLite;

namespace MobileApp.Models
{
    [Table("ticket")]
    public class Ticket : NotifyPropertyChanged
    {
        private int id;
        private string title;
        private int retailShopId;
        private int merchandiserId;
        private DateTime scheduledDate;
        private string status;
        private string comment;


        [PrimaryKey, AutoIncrement]
        public int Id
        {
            get { return this.id; }
            set
            {
                this.id = value;
                OnPropertyChanged();
            }
        }

        [NotNull]
        public string Title
        {
            get { return this.title; }
            set
            {
                this.title = value;
                OnPropertyChanged();

            }
        }

        [NotNull]
        public int RetailShopId
        {
            get { return this.retailShopId; }
            set
            {
                this.retailShopId = value;
                OnPropertyChanged();
            }
        }

        public int MerchandiserId
        {
            get { return this.merchandiserId; }
            set
            {
                this.merchandiserId = value;
                OnPropertyChanged();
            }
        }

        public DateTime ScheduledDate
        {
            get { return this.scheduledDate; }
            set
            {
                this.scheduledDate = value;
                OnPropertyChanged();
            }
        }

        [NotNull]
        public string Status
        {
            get { return this.status; }
            set
            {
                this.status = value;
                OnPropertyChanged();
            }
        }

        public string Comment
        {
            get { return this.comment; }
            set
            {
                this.comment = value;
                OnPropertyChanged();
            }
        }

    }
}