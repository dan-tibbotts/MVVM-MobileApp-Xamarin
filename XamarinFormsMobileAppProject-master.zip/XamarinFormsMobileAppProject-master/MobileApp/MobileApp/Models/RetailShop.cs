﻿using SQLite;

namespace MobileApp.Models
{
    [Table("retailshop")]
    public class RetailShop : NotifyPropertyChanged
    {
        private int id;
        private string name;
        private string phone;
        private string email;

        [PrimaryKey, AutoIncrement]
        public int Id
        {
            get { return this.id; }
            set
            {
                this.id = value;
                OnPropertyChanged();
            }
        }

        [NotNull]
        public string Name
        {
            get { return this.name; }
            set
            {
                this.name = value;
                OnPropertyChanged();
            }
        }

        public string Phone
        {
            get { return this.phone; }
            set
            {
                this.phone = value;
                OnPropertyChanged();
            }
        }

        public string Email
        {
            get { return this.email; }
            set
            {
                this.email = value;
                OnPropertyChanged();
            }
        }
    }
}
